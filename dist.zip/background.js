chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0}).catch(e=>console.error(e));chrome.runtime.onInstalled.addListener(()=>{console.log("nanobanana.fans extension installed")});
